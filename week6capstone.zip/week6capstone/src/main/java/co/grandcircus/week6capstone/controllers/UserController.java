package co.grandcircus.week6capstone.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {

	@RequestMapping("/")
	public ModelAndView welcomePage() {
		return new ModelAndView("welcome-login");
	}

}
