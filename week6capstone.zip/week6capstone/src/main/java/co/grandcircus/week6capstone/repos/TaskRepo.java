package co.grandcircus.week6capstone.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import co.grandcircus.week6capstone.models.Task;

public interface TaskRepo extends JpaRepository<Task, Integer>{
	
	Task findByTaskDescription(String taskDescription);

}
