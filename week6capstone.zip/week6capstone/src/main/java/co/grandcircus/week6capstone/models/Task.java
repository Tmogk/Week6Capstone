package co.grandcircus.week6capstone.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tasks")
public class Task {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer userId;
	private String taskDescription;
	private String dueDate;
	private boolean completionStatus;
	
	@ManyToOne
	private User user;

	public Task() {
		super();
	}

	public Task(String taskDescription, String dueDate, boolean completionStatus) {
		super();
		this.taskDescription = taskDescription;
		this.dueDate = dueDate;
		this.completionStatus = completionStatus;
	}

	public Task(Integer id, String taskDescription, String dueDate, boolean completionStatus) {
		super();
		this.userId = id;
		this.taskDescription = taskDescription;
		this.dueDate = dueDate;
		this.completionStatus = completionStatus;
	}

	public Integer getId() {
		return userId;
	}

	public void setId(Integer id) {
		this.userId = id;
	}

	public String getTaskDescription() {
		return taskDescription;
	}

	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public boolean isCompletionStatus() {
		return completionStatus;
	}

	public void setCompletionStatus(boolean completionStatus) {
		this.completionStatus = completionStatus;
	}
	
	

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Task [id=" + userId + ", taskDescription=" + taskDescription + ", dueDate=" + dueDate
				+ ", completionStatus=" + completionStatus + "]";
	}
	
	

}
