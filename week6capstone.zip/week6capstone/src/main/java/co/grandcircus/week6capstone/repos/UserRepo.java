package co.grandcircus.week6capstone.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import co.grandcircus.week6capstone.models.Task;
import co.grandcircus.week6capstone.models.User;

public interface UserRepo extends JpaRepository<User, Integer>{
	
	User findByUserId(String userId);
	
}
