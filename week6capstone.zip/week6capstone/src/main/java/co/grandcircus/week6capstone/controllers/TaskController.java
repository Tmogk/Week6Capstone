package co.grandcircus.week6capstone.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import co.grandcircus.week6capstone.models.Task;
import co.grandcircus.week6capstone.models.User;
import co.grandcircus.week6capstone.repos.TaskRepo;
import co.grandcircus.week6capstone.repos.UserRepo;

@Controller
public class TaskController {
	
	@Autowired
	TaskRepo tRepo;
	@Autowired
	UserRepo uRepo;
	
	@RequestMapping("/task-list")
	public ModelAndView taskPage() {
		ModelAndView mv = new ModelAndView("task-list", "taskList", tRepo.findAll());
		return mv;
	}
	
	@RequestMapping("/add-task")
	public ModelAndView addTask(Task task, String userName) {
//		User user = uRepo.findByUserId(userName);
//		task.setUser(user);
//		tRepo.save(task);
		return new ModelAndView("add-task");
	}

}
