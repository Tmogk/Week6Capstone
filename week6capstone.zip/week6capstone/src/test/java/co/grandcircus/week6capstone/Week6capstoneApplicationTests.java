package co.grandcircus.week6capstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week6capstoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
